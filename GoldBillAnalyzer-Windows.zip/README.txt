GOLD BILL ANALYZER  -  Windows desktop app, 100% offline
=========================================================

WHAT IT DOES
 - Upload photos or scans of bills: the app reads them and fills in the
   form for you, all on this PC.
 - Store every gold bill: date, shop, item, karat, gross/stone/net weight,
   rate per gram, making charges (per gram, % or fixed), stone charges,
   discount, VAT and the total printed on the bill. You can attach a scan or photo.
 - Checks every bill and flags:
     * a total that doesn't match the calculation
     * VAT that doesn't match
     * net weight that isn't gross minus stone
     * making charges above your limit (default 15% of gold value)
     * a gold rate above your reference rate (default more than 2%)
 - Analysis: total spent, net and pure (fine) gold grams, average cost per
   gram of pure gold, making charges and VAT paid, a breakdown by shop,
   karat, month or category, a monthly spending chart, and what your gold
   is worth at today's rates.
 - Export to CSV (opens in Excel), import from CSV, backup and restore,
   and an optional password.

INDIA
  Gold rates & Settings > Region > India switches the app to rupees with lakh grouping
  (1,20,224.00) and GST:
  - GST at 3% on the whole bill, or 3% on gold + 5% on making when the bill taxes making
    separately (CGST + SGST / IGST lines are added up when a bill is read).
  - Hallmark: 20K and 23K grades, and a HUID box per item (read from the bill and checked
    to be 6 letters/digits - verify it in the BIS CARE app).
  - Read from Indian bills: wastage / VA %, hallmarking charges (shared over the items),
    rates per 10 g, old-gold exchange (the bill's total stays the price; the old gold and the
    amount paid go in the notes), UPI payments, amounts in words with lakh / crore / paise.
  Saved bills are not changed when you switch region.

ZAKAT
  The Zakat tab works out zakat on the gold in your bills, valued at today's rate from
  Gold rates & Settings:
  - Pure gold is counted from each bill's net weight and karat. Mark each bill as
    "Savings / investment", "Worn jewellery" or "Sold / given away" (on the bill, or select
    bills on the Zakat tab). Sold pieces are never counted.
  - Worn jewellery is counted by default; tick "Leave out jewellery marked Worn" if the
    view you follow exempts it.
  - Nisab: 85 g of pure gold, or the value of 595 g of silver (type today's silver rate).
  - Zakat is 2.5% of the value once the gold is at or above the nisab. The date your gold
    first reached the nisab is worked out from the bill dates, with the dates a full lunar
    year (354 days) later.
  Schools and scholars differ on worn jewellery and the nisab - the settings let you
  follow the view you rely on.

SECURITY
 - The app switches off all networking when it starts, so it cannot
   connect to the internet even by accident.
 - Everything is ENCRYPTED on this PC with AES-256: the bills file
   (bills.gbenc) and every bill image (*.enc) in
       %LOCALAPPDATA%\GoldBillAnalyzer
 - No password set: the key is locked to your Windows account (Windows
   DPAPI). Another Windows user, or someone who takes the disk, can't
   read it.
 - Password set (Gold rates & Settings > Security): the data can't be
   opened without the password. You also get a RECOVERY CODE, shown once.
   Write it on paper. If you forget the password, leave the password box
   empty at start-up and press OK to enter the recovery code.
   "New recovery code" makes a fresh one (the old one stops working).
 - Images are decrypted only while you look at them or the text is read,
   into a temporary folder that is wiped when the app closes.
 - Bills from an older version are encrypted automatically the first
   time this version opens (a password you had is kept).

ENCRYPTED BACKUPS (.goldbackup)
 - "Encrypted backup..." saves all bills AND their images in one file,
   locked with a backup password you choose (at least 8 characters).
 - The same file opens in the Android app, so it is the safe way to move
   bills between PC and phone (USB, cloud drive, e-mail).
 - "Import bills from backup..." adds the bills (ones already here are
   skipped). "Restore backup (replace all)..." swaps everything; a safety
   copy of the current data is kept as bills.before_restore.gbenc.
 - Old .db backups from earlier versions can still be imported.
 - CSV exports are NOT encrypted (Excel needs plain files); the app warns
   you before saving one.

HOW TO GET THE .EXE (once)
 1. Install Python 3.10 or newer from python.org and tick "Add Python to PATH".
 2. Double-click build_exe.bat. It needs the internet once to download the
    PyInstaller build tool.
 3. Your app is dist\GoldBillAnalyzer.exe. Copy it anywhere. From then on
    it runs with no internet.
 (Or run it without building: double-click run_app.bat.)

UPLOADING BILL IMAGES (read automatically, offline)
 - Click "Upload bill images..." and choose one or more photos or scans
   (JPG, PNG, BMP, TIFF). Phone photos are fine; it fixes their rotation.
 - The app reads each image on this PC and opens the bill form already
   filled in, with the photo beside it. You can zoom with + / - or
   Ctrl + mouse wheel, and check the "Text read from image" tab.
 - A yellow note says what was found and what wasn't. Compare the values
   with the photo, correct anything wrong, then Save. The next image opens
   automatically.
 - It looks for: shop, bill no., date, karat, gross/stone/net weight,
   rate, making charges, stone charges, discount, VAT % and amount, total,
   item and category.
 - If the date can't be read you must type it in. The app never guesses
   today's date for an uploaded bill.
 - In a bill you're typing by hand: "Attach image..." then
   "Read bill from image" fills only the fields that are still empty.

 BILLS IN OTHER LANGUAGES
 - In Gold rates & Settings > Reading bill images, tick the languages on
   your bills: Arabic, Urdu, Persian, Hindi/Marathi, Malayalam, Tamil,
   Telugu, Kannada, Gujarati, Bengali, Chinese, Japanese, Korean, Russian,
   French, German, Spanish, Italian, Portuguese, Turkish. English is
   always read. Click "Check which languages this PC can read".
 - Bill words are recognised in all of these: total, VAT/GST, gross/net
   weight, rate, making, discount, bill no., date, karat (عيار, कैरेट, 足金),
   and item names. Digits in Arabic, Hindi and other scripts are converted.
   Indian CGST + SGST are added together as the GST.
 - Windows can read Arabic, Chinese, Japanese, Korean, Russian and European
   languages once that language is added in Windows Settings > Time &
   language > Language (Windows downloads it once).
 - Indian languages, Urdu and Persian need the free Tesseract OCR. While
   installing it, open "Additional language data" and tick the languages.
 - In "Automatic" mode each language is read by whichever engine has it.

MANAGING AND DELETING UPLOADS
 - Bills tab > "Manage uploads" lists every uploaded image/PDF, when it
   was added, its size and which bills use it.
     * Delete image only: the bills keep all their details.
     * Delete image and its bills.
     * Delete all unused: files left from skipped or replaced uploads.
 - Deleting a bill also deletes its image, unless another bill (another
   item from the same bill) still uses it.
 - Images from uploads you skip or cancel are deleted automatically.
 - In a bill, "Remove image" takes the image off; the file is deleted
   when you save.
 - Your original files (in Downloads, Pictures...) are never touched; the
   app only deletes its own copies.

 Which reader is used (Settings > Reading bill images):
 - Windows built-in OCR: part of Windows 10/11, nothing to install, fully
   offline. It reads in your Windows display language. If it says no
   language is installed, add English in Settings > Time & language.
 - Tesseract OCR (optional, free): install it from the official
   UB-Mannheim Windows installer and the app finds it automatically.
   It is sometimes better on faint thermal receipts.
 - "Automatic" tries Windows first, then Tesseract.
 Tips: photograph the bill flat, in good light, filling the frame.
 Handwritten bills won't read well, so type those in.

COST PER ITEM - WITH AND WITHOUT VAT
 - BILLS WITH SEVERAL ITEMS are split automatically when read from an
   image: each item row (or block of lines) becomes its own entry with its
   own weights, rate and making; shop, bill no., date and VAT are shared.
   The note at the top lists every item found and checks that they add up
   to the bill's total. Check item 1, then "Save & next item" - or "Save all
   items". A fix to the shop/date/bill no. carries on to the next items.
 - Typing a bill in by hand: "Save & add another" keeps the bill details.
 - Analysis > breakdown by "Bill" shows each bill with its items together.
 - Every item shows: cost without VAT, VAT paid, cost with VAT, and the
   cost per gram with and without VAT.
     * If you type the VAT shown on the bill, that figure is used.
       If not, the app works it out from the VAT % you entered.
     * If the bill gives one total for several items, leave each item's
       total empty and the app uses the calculated figures.
 - Bills tab: "Without VAT", "VAT" and "With VAT" columns, with totals
   along the bottom.
 - Analysis tab: breakdown by Item, Category, Shop, Karat or Month,
   with a TOTAL row.
 - "Item cost report (Excel)" saves a clean list of every item with
   these figures and a total at the end. It respects the current filters,
   so you can produce one for a single year or a single shop.

FIRST STEPS
 1. Open the "Gold rates & Settings" tab and type today's per-gram rates
    from your jeweller's board. "Fill other karats from 24K" works out the
    rest. Change the currency or VAT here if you need to (defaults: AED, 5%).
 2. Click "Add bill" (Ctrl+N) and type in the bill. The panel on the right
    checks it as you type. "Save & add another" keeps the date, shop and
    rate, which is handy for bills with several items.
 3. Rows that need checking are highlighted in red. The Analysis tab lists
    every problem found.
 To try it out: Import CSV -> sample_bills.csv (made-up example bills).

NOTES ON THE CHECKS
 - Pure gold uses standard fineness: 24K=0.999, 22K=0.916, 21K=0.875,
   18K=0.750, 14K=0.585, 9K=0.375.
 - "VAT applies to" can be Whole bill, Making + stone only, or No VAT
   (for example investment bars and coins).
 - "Value at ref. rates" is the melt value: net weight x today's rate.
   It leaves out making charges and VAT, so new jewellery usually shows
   less than you paid.

FILES
 gold_bills_app.py   the application (window and screens)
 gold_core.py        calculations, checks, database
 gold_ocr.py         reads bill images (Windows OCR / Tesseract) in many languages
 gold_parse.py       finds the bill fields in the text read (all languages)
 gold_lexicon.py     bill words in ~20 languages (shared with the Android app)
 gold_crypto.py      encryption, recovery codes and the backup format
 build_exe.bat       builds the .exe
 run_app.bat         runs it with Python
 sample_bills.csv    example data
